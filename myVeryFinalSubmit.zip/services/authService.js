/*
const userModel = require('../models/userModel')

async function findOneUser(username){
    const user = userModel.findOne({username: username})
}


module.exports = {findOneUser}
*/